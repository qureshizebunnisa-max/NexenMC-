NEXENMC WEBSITE
Updated server address: Nexen.mcsh.gg
Extract and upload all three website files together to your host.
Ranks and Coins sections are placeholders until Tebex package checkout links are connected.
Replace support@nexenmc.com with your real support email.
